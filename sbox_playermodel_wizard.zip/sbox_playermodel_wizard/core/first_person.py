"""First-person arms workflow helpers."""

import os

import bpy
from mathutils import Matrix, Vector

from .meshes import remove_mesh_shapekeys
from .scene import (
    FIRST_PERSON_COLLECTION,
    ensure_scene_collection,
    model_mesh_objects,
    object_in_collection,
)

ARM_PROFILE_SAMPLE_POINTS = (0.15, 0.35, 0.55, 0.75)
FP_DELETE_GROUP = "sbox_fp_delete"
FP_MARK_HAND = "HAND"
FP_MARK_FOREARM = "FOREARM"


def first_person_arm_weight_bone(name):
    lowered = name.lower()
    if "hair" in lowered or "head" in lowered or "skull" in lowered or "face" in lowered:
        return False
    if "clavicle" in lowered or "shoulder" in lowered:
        return False
    return (
        name.startswith("arm_upper_")
        or name.startswith("arm_lower_")
        or name.startswith("hand_")
        or name.startswith("finger_")
        or "arm_upper" in lowered
        or "arm_lower" in lowered
        or "hand" in lowered
        or "finger" in lowered
        or "wrist" in lowered
        or "elbow" in lowered
        or "twist" in lowered
        or "手" in name
        or "腕" in name
        or "指" in name
        or "肘" in name
        or "手首" in name
        or "ひじ" in name
    )


def fp_attachment_group_name(mark_kind, side):
    if mark_kind == FP_MARK_HAND:
        return f"sbox_fp_attach_hand_{side}"
    if mark_kind == FP_MARK_FOREARM:
        return f"sbox_fp_attach_forearm_{side}"
    return ""


def vertex_has_group_weight(vertex, group_index):
    if group_index is None:
        return False
    for assignment in vertex.groups:
        if assignment.group == group_index and assignment.weight > 0.0:
            return True
    return False


def bone_world_frame(armature, bone_name):
    bone = armature.data.bones.get(bone_name)
    if not bone:
        return None
    head = armature.matrix_world @ bone.head_local
    tail = armature.matrix_world @ bone.tail_local
    axis = tail - head
    length = axis.length
    if length < 0.0001:
        return None
    axis.normalize()
    return head, tail, axis, length


def sample_arm_profile(meshes, armature, bone_name, sample_points):
    frame = bone_world_frame(armature, bone_name)
    if not frame:
        return []
    head, tail, axis, length = frame
    slice_half_width = length * 0.04
    radial_limit = length * 0.9
    profile = []

    for sample_t in sample_points:
        center = head.lerp(tail, sample_t)
        radii = []
        for obj in meshes:
            if obj.type != "MESH":
                continue
            for vertex in obj.data.vertices:
                world = obj.matrix_world @ vertex.co
                offset = world - center
                along = offset.dot(axis)
                if abs(along) > slice_half_width:
                    continue
                radial = (offset - axis * along).length
                if radial > radial_limit:
                    continue
                radii.append(radial)
        if len(radii) < 6:
            continue
        radii.sort()
        profile.append((sample_t, radii[len(radii) // 2]))
    return profile


def build_template_arm_profiles(armature, meshes):
    profiles = {}
    for side in ("L", "R"):
        profiles[side] = {
            f"arm_upper_{side}": sample_arm_profile(meshes, armature, f"arm_upper_{side}", ARM_PROFILE_SAMPLE_POINTS),
            f"arm_lower_{side}": sample_arm_profile(meshes, armature, f"arm_lower_{side}", ARM_PROFILE_SAMPLE_POINTS),
        }
    return profiles


def interpolate_profile_value(profile, sample_t):
    if not profile:
        return None
    if sample_t <= profile[0][0]:
        return profile[0][1]
    if sample_t >= profile[-1][0]:
        return profile[-1][1]
    for index in range(len(profile) - 1):
        left_t, left_value = profile[index]
        right_t, right_value = profile[index + 1]
        if sample_t > right_t:
            continue
        span = max(right_t - left_t, 0.0001)
        blend = (sample_t - left_t) / span
        return left_value + (right_value - left_value) * blend
    return profile[-1][1]


def first_person_template_bone(name):
    return (
        name in {
            "root",
            "camera",
            "weapon_root",
            "weapon_root_children",
            "clavicle_L",
            "clavicle_R",
            "hand_R_to_L_ikrule",
            "hand_L_to_R_ikrule",
            "hand_R_to_weapon_ikrule",
            "hand_L_to_weapon_ikrule",
            "weapon_IK_hand_L",
            "weapon_IK_hand_R",
        }
        or first_person_arm_weight_bone(name)
    )


def import_first_person_template_armature(context, filepath):
    filepath = bpy.path.abspath(filepath)
    if not filepath or not os.path.exists(filepath):
        raise FileNotFoundError("First person arms template FBX was not found.")

    before = set(bpy.data.objects)
    bpy.ops.import_scene.fbx(filepath=filepath)
    imported = [obj for obj in bpy.data.objects if obj not in before]
    armatures = [obj for obj in imported if obj.type == "ARMATURE"]
    if not armatures:
        raise RuntimeError("Template FBX did not import an armature.")

    def score(armature):
        names = {bone.name for bone in armature.data.bones}
        return sum(1 for name in ("root", "camera", "weapon_root", "hand_R", "hand_L") if name in names)

    armature = max(armatures, key=score)
    armature.name = "First Person Arms Working"
    armature.data.name = "First Person Arms Working Skeleton"
    template_meshes = [obj for obj in imported if obj.type == "MESH"]
    template_profiles = build_template_arm_profiles(armature, template_meshes)

    collection = ensure_scene_collection(context.scene, FIRST_PERSON_COLLECTION)
    if not object_in_collection(armature, collection):
        collection.objects.link(armature)
    for old_collection in list(armature.users_collection):
        if old_collection != collection:
            old_collection.objects.unlink(armature)

    for obj in imported:
        if obj != armature and obj.type == "MESH":
            bpy.data.objects.remove(obj, do_unlink=True)

    return armature, template_profiles


def matching_first_person_bone_count(source_armature, target_armature):
    source_names = {bone.name for bone in source_armature.data.bones}
    return sum(
        1
        for bone in target_armature.data.bones
        if bone.name in source_names and first_person_arm_weight_bone(bone.name)
    )


def side_from_bone_name(name):
    lowered = name.lower()
    if lowered.endswith("_l") or "_l_" in lowered or "left" in lowered or "左" in name:
        return "L"
    if lowered.endswith("_r") or "_r_" in lowered or "right" in lowered or "右" in name:
        return "R"
    return ""


def dominant_arm_side(vertex, index_to_name):
    weights = {"L": 0.0, "R": 0.0}
    for assignment in vertex.groups:
        group_name = index_to_name.get(assignment.group)
        if not group_name or not first_person_arm_weight_bone(group_name):
            continue
        side = side_from_bone_name(group_name)
        if side:
            weights[side] += assignment.weight
    if weights["L"] <= 0.0 and weights["R"] <= 0.0:
        return ""
    return "L" if weights["L"] >= weights["R"] else "R"


def create_first_person_reference_armature(context, target_armature):
    reference = target_armature.copy()
    reference.data = target_armature.data.copy()
    reference.name = "First Person Arms Reference"
    reference.data.name = "First Person Arms Reference Skeleton"

    collection = ensure_scene_collection(context.scene, FIRST_PERSON_COLLECTION)
    collection.objects.link(reference)
    for old_collection in list(reference.users_collection):
        if old_collection != collection:
            old_collection.objects.unlink(reference)

    reference.hide_viewport = False
    reference.hide_render = True
    return reference


def move_first_person_armature_to_source(source_armature, target_armature):
    if bpy.context.object:
        bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    target_armature.select_set(True)
    bpy.context.view_layer.objects.active = target_armature
    bpy.ops.object.mode_set(mode="EDIT")
    target_bones = target_armature.data.edit_bones
    moved = 0
    for target_bone in target_bones:
        source_bone = source_armature.data.bones.get(target_bone.name)
        if not source_bone or not first_person_arm_weight_bone(target_bone.name):
            continue
        
        # 保持目标骨骼的原始方向（保证T-Pose正确），只移动头尾位置
        old_dir = target_bone.tail - target_bone.head
        old_length = old_dir.length
        if old_length < 0.001:
            old_dir = source_bone.tail_local - source_bone.head_local
            old_length = old_dir.length
            if old_length < 0.001:
                continue
                
        source_head_world = source_armature.matrix_world @ source_bone.head_local
        target_bone.head = target_armature.matrix_world.inverted() @ source_head_world
        target_bone.tail = target_bone.head + old_dir.normalized() * old_length
        moved += 1
        
    point_table = {
        "arm_upper_R": "arm_lower_R",
        "arm_lower_R": "hand_R",
        "arm_lower_R_twist0": "hand_R",
        "arm_lower_R_twist1": "hand_R",
        "arm_lower_R_twist2": "hand_R",
        "hand_R": "",
        "arm_upper_L": "arm_lower_L",
        "arm_lower_L": "hand_L",
        "arm_lower_L_twist0": "hand_L",
        "arm_lower_L_twist1": "hand_L",
        "arm_lower_L_twist2": "hand_L",
        "hand_L": "",
    }
    last_direction = None
    for bone_name, child_name in point_table.items():
        bone = target_bones.get(bone_name)
        if not bone:
            continue
        length = bone.length
        if child_name:
            child = target_bones.get(child_name)
            if not child:
                continue
            direction = child.head - bone.head
            if direction.length < 0.001:
                continue
            direction.normalize()
            bone.tail = bone.head + direction * length
            last_direction = direction
        elif last_direction:
            bone.tail = bone.head + last_direction * length
            
    bpy.ops.object.mode_set(mode="OBJECT")
    return moved


def make_arm_basis(armature, side):
    upper = armature.data.bones.get(f"arm_upper_{side}")
    lower = armature.data.bones.get(f"arm_lower_{side}")
    hand = armature.data.bones.get(f"hand_{side}")
    if not upper or not lower or not hand:
        return None, 1.0

    origin = armature.matrix_world @ upper.head_local
    elbow = armature.matrix_world @ lower.head_local
    wrist = armature.matrix_world @ hand.head_local
    x_axis = wrist - origin
    if x_axis.length < 0.0001:
        return None, 1.0
    length = x_axis.length
    x_axis.normalize()

    elbow_offset = elbow - origin
    y_axis = elbow_offset - x_axis * elbow_offset.dot(x_axis)
    if y_axis.length < 0.0001:
        y_axis = Vector((0.0, 0.0, 1.0))
        if abs(x_axis.dot(y_axis)) > 0.95:
            y_axis = Vector((0.0, 1.0, 0.0))
        y_axis = y_axis - x_axis * y_axis.dot(x_axis)
    y_axis.normalize()
    z_axis = x_axis.cross(y_axis)
    if z_axis.length < 0.0001:
        return None, 1.0
    z_axis.normalize()
    y_axis = z_axis.cross(x_axis)
    y_axis.normalize()

    basis = Matrix(
        (
            (x_axis.x, y_axis.x, z_axis.x, origin.x),
            (x_axis.y, y_axis.y, z_axis.y, origin.y),
            (x_axis.z, y_axis.z, z_axis.z, origin.z),
            (0.0, 0.0, 0.0, 1.0),
        )
    )
    return basis, length


def retarget_mesh_to_first_person_template(obj, source_armature, target_armature, side):
    source_basis, source_length = make_arm_basis(source_armature, side)
    target_basis, target_length = make_arm_basis(target_armature, side)
    if source_basis is None or target_basis is None or source_length < 0.0001:
        return 0

    scale = target_length / source_length
    source_inverse = source_basis.inverted_safe()
    new_world_coords = []
    for vertex in obj.data.vertices:
        local = source_inverse @ (obj.matrix_world @ vertex.co)
        local.x *= scale
        local.y *= scale
        local.z *= scale
        new_world_coords.append(target_basis @ local)

    obj.parent = None
    obj.matrix_parent_inverse = Matrix.Identity(4)
    obj.matrix_world = Matrix.Identity(4)
    for vertex, world_coord in zip(obj.data.vertices, new_world_coords):
        vertex.co = world_coord
    obj.data.update()
    return len(new_world_coords)


def reweight_wrist_vertices_to_hand(obj, source_armature, side, radius_factor):
    source_basis, source_length = make_arm_basis(source_armature, side)
    if source_basis is None or source_length < 0.0001:
        return 0

    hand_name = f"hand_{side}"
    lower_name = f"arm_lower_{side}"
    hand_group = obj.vertex_groups.get(hand_name)
    if not hand_group:
        return 0
    lower_group = obj.vertex_groups.get(lower_name)

    source_inverse = source_basis.inverted_safe()
    forearm_band = source_length * max(radius_factor * 1.15, 0.0)
    hand_band = source_length * max(radius_factor * 1.35, 0.0)
    radial_outer = source_length * max(radius_factor * 3.0, 0.0)
    if forearm_band <= 0.0 or hand_band <= 0.0 or radial_outer <= 0.0:
        return 0

    changed = 0
    for vertex in obj.data.vertices:
        local = source_inverse @ (obj.matrix_world @ vertex.co)
        offset_from_wrist = local.x - source_length
        radial_distance = (local.y * local.y + local.z * local.z) ** 0.5
        if offset_from_wrist < -forearm_band or offset_from_wrist > hand_band:
            continue
        if radial_distance > radial_outer:
            continue

        assignment_by_group = {
            assignment.group: assignment.weight
            for assignment in vertex.groups
        }
        hand_weight = assignment_by_group.get(hand_group.index, 0.0)
        lower_weight = assignment_by_group.get(lower_group.index, 0.0) if lower_group else 0.0
        finger_weight = 0.0
        for group in obj.vertex_groups:
            if not group.name.startswith("finger_"):
                continue
            finger_weight += assignment_by_group.get(group.index, 0.0)
        if hand_weight + lower_weight < 0.25:
            continue
        if finger_weight > hand_weight + lower_weight:
            continue

        for group in list(obj.vertex_groups):
            if group.name in {hand_name, lower_name}:
                continue
            if group.name.startswith("finger_"):
                try:
                    group.remove([vertex.index])
                except RuntimeError:
                    pass
        hand_group.add([vertex.index], 0.82, "REPLACE")
        if lower_group:
            lower_group.add([vertex.index], 0.18, "REPLACE")
        changed += 1

    return changed


def mesh_vertex_islands(mesh):
    links = {index: set() for index in range(len(mesh.vertices))}
    for edge in mesh.edges:
        a, b = edge.vertices
        links[a].add(b)
        links[b].add(a)

    islands = []
    seen = set()
    for index in links:
        if index in seen:
            continue
        stack = [index]
        seen.add(index)
        island = []
        while stack:
            current = stack.pop()
            island.append(current)
            for neighbor in links[current]:
                if neighbor in seen:
                    continue
                seen.add(neighbor)
                stack.append(neighbor)
        islands.append(island)
    return islands


def reweight_wrist_accessory_islands_to_hand(obj, source_armature, side, radius_factor):
    source_basis, source_length = make_arm_basis(source_armature, side)
    if source_basis is None or source_length < 0.0001:
        return 0

    hand_name = f"hand_{side}"
    lower_name = f"arm_lower_{side}"
    hand_group = obj.vertex_groups.get(hand_name)
    if not hand_group:
        return 0
    lower_group = obj.vertex_groups.get(lower_name)

    source_inverse = source_basis.inverted_safe()
    wrist_band = source_length * max(radius_factor * 1.4, 0.0)
    outer_radius = source_length * max(radius_factor * 5.0, 0.0)
    total_vertices = max(len(obj.data.vertices), 1)
    changed = 0

    for island in mesh_vertex_islands(obj.data):
        if len(island) > total_vertices * 0.30 or len(island) > 900:
            continue

        has_hand_anchor = False
        max_distance_from_wrist = 0.0
        for index in island:
            vertex = obj.data.vertices[index]
            local = source_inverse @ (obj.matrix_world @ vertex.co)
            distance_from_wrist = abs(source_length - local.x)
            radial_distance = (local.y * local.y + local.z * local.z) ** 0.5
            max_distance_from_wrist = max(max_distance_from_wrist, distance_from_wrist)
            if distance_from_wrist > wrist_band:
                continue

            hand_weight = 0.0
            lower_weight = 0.0
            for assignment in vertex.groups:
                if assignment.group == hand_group.index:
                    hand_weight = assignment.weight
                elif lower_group and assignment.group == lower_group.index:
                    lower_weight = assignment.weight
            if hand_weight >= 0.08 and hand_weight + lower_weight >= 0.20 and radial_distance <= outer_radius:
                has_hand_anchor = True
                break

        if not has_hand_anchor or max_distance_from_wrist < source_length * max(radius_factor * 1.8, 0.0):
            continue

        for index in island:
            for group in list(obj.vertex_groups):
                if group.name == hand_name:
                    continue
                try:
                    group.remove([index])
                except RuntimeError:
                    pass
            hand_group.add([index], 1.0, "REPLACE")
            changed += 1

    return changed


def find_supported_first_person_parent(source_armature, bone_name, supported_names):
    bone = source_armature.data.bones.get(bone_name)
    while bone and bone.parent:
        bone = bone.parent
        if bone.name in supported_names:
            return bone.name
    return None


def collapse_first_person_unsupported_groups(obj, source_armature, supported_names):
    remap_pairs = []
    for group in obj.vertex_groups:
        if group.name in supported_names:
            continue
        target_name = find_supported_first_person_parent(source_armature, group.name, supported_names)
        if target_name:
            remap_pairs.append((group.name, target_name))

    transferred = 0
    for source_name, target_name in remap_pairs:
        source_group = obj.vertex_groups.get(source_name)
        if not source_group:
            continue
        target_group = obj.vertex_groups.get(target_name)
        if not target_group:
            target_group = obj.vertex_groups.new(name=target_name)

        source_index = source_group.index
        for vertex in obj.data.vertices:
            weight = 0.0
            for assignment in vertex.groups:
                if assignment.group == source_index:
                    weight = assignment.weight
                    break
            if weight > 0.0:
                target_group.add([vertex.index], weight, "ADD")
                transferred += 1

    for group in list(obj.vertex_groups):
        if group.name not in supported_names:
            obj.vertex_groups.remove(group)

    return transferred


def repair_first_person_unweighted_vertices(obj, source_armature, side):
    source_basis, source_length = make_arm_basis(source_armature, side)
    if source_basis is None or source_length < 0.0001:
        return 0

    hand_group = obj.vertex_groups.get(f"hand_{side}")
    if not hand_group:
        return 0
    lower_group = obj.vertex_groups.get(f"arm_lower_{side}")
    source_inverse = source_basis.inverted_safe()

    repaired = 0
    for vertex in obj.data.vertices:
        if vertex.groups:
            continue
        local = source_inverse @ (obj.matrix_world @ vertex.co)
        if lower_group and local.x < source_length:
            lower_group.add([vertex.index], 1.0, "REPLACE")
        else:
            hand_group.add([vertex.index], 1.0, "REPLACE")
        repaired += 1
    return repaired


def apply_first_person_attachment_marks(obj, side):
    target_map = (
        (fp_attachment_group_name(FP_MARK_HAND, side), f"hand_{side}"),
        (fp_attachment_group_name(FP_MARK_FOREARM, side), f"arm_lower_{side}"),
    )
    marker_names = {FP_DELETE_GROUP}
    for mark_kind in (FP_MARK_HAND, FP_MARK_FOREARM):
        for mark_side in ("L", "R"):
            marker_names.add(fp_attachment_group_name(mark_kind, mark_side))

    changed = 0
    for marker_name, target_name in target_map:
        marker_group = obj.vertex_groups.get(marker_name)
        if not marker_group:
            continue
        target_group = obj.vertex_groups.get(target_name)
        if not target_group:
            target_group = obj.vertex_groups.new(name=target_name)

        marked_indices = [
            vertex.index
            for vertex in obj.data.vertices
            if vertex_has_group_weight(vertex, marker_group.index)
        ]
        for index in marked_indices:
            for group in list(obj.vertex_groups):
                try:
                    group.remove([index])
                except RuntimeError:
                    pass
            target_group.add([index], 1.0, "REPLACE")
            changed += 1

    for marker_name in marker_names:
        group = obj.vertex_groups.get(marker_name)
        if group:
            obj.vertex_groups.remove(group)
    return changed


def inflate_mesh_to_template_profile(
    obj,
    target_armature,
    template_profiles,
    side,
    thickness_scale=1.10,
    max_scale=2.0,
):
    thickness_scale = max(0.0, min(1.5, thickness_scale))
    if thickness_scale <= 0.0:
        return 0
    blend = min(thickness_scale, 1.0)
    target_multiplier = max(thickness_scale, 1.0)

    side_profiles = template_profiles.get(side, {}) if template_profiles else {}
    if not side_profiles:
        return 0

    profile_pairs = {}
    for bone_name, target_profile in side_profiles.items():
        if not target_profile:
            continue
        sample_points = [sample_t for sample_t, _ in target_profile]
        current_profile = sample_arm_profile([obj], target_armature, bone_name, sample_points)
        current_map = {sample_t: radius for sample_t, radius in current_profile}
        ratio_profile = []
        for sample_t, target_radius in target_profile:
            current_radius = current_map.get(sample_t)
            if not current_radius or current_radius < 0.0001:
                continue
            target_ratio = max(1.0, min(max_scale, (target_radius * target_multiplier) / current_radius))
            ratio = 1.0 + (target_ratio - 1.0) * blend
            ratio_profile.append((sample_t, ratio))
        if ratio_profile:
            profile_pairs[bone_name] = (target_profile, current_profile, ratio_profile)

    if not profile_pairs:
        return 0

    inverse_world = obj.matrix_world.inverted_safe()
    changed = 0
    for vertex in obj.data.vertices:
        world = obj.matrix_world @ vertex.co
        best_match = None

        for bone_name, (_, current_profile, ratio_profile) in profile_pairs.items():
            frame = bone_world_frame(target_armature, bone_name)
            if not frame:
                continue
            head, tail, axis, length = frame
            offset = world - head
            along = offset.dot(axis)
            sample_t = along / length
            if sample_t < -0.05 or sample_t > 1.05:
                continue

            closest = head + axis * along
            radial_vector = world - closest
            radial_distance = radial_vector.length
            current_radius = interpolate_profile_value(current_profile, max(0.0, min(1.0, sample_t)))
            if not current_radius or radial_distance > current_radius * 1.6:
                continue

            score = radial_distance / max(current_radius, 0.0001)
            if best_match is None or score < best_match[0]:
                best_match = (
                    score,
                    max(0.0, min(1.0, sample_t)),
                    closest,
                    radial_vector,
                    ratio_profile,
                )

        if best_match is None:
            continue

        _, sample_t, closest, radial_vector, ratio_profile = best_match
        ratio = interpolate_profile_value(ratio_profile, sample_t)
        if not ratio or ratio <= 1.01:
            continue

        new_world = closest + radial_vector * ratio
        vertex.co = inverse_world @ new_world
        changed += 1

    if changed:
        obj.data.update()
    return changed


def bake_first_person_meshes_to_reference(context, working_armature, reference_armature, meshes):
    if bpy.context.object:
        bpy.ops.object.mode_set(mode="OBJECT")

    for pbone in working_armature.pose.bones:
        if not reference_armature.pose.bones.get(pbone.name):
            continue
        constraint = pbone.constraints.new("COPY_ROTATION")
        constraint.name = "sbox_first_person_reference_rotation"
        constraint.target = reference_armature
        constraint.subtarget = pbone.name

    context.view_layer.update()

    for mesh in meshes:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        context.view_layer.objects.active = mesh
        mesh.select_set(True)
        remove_mesh_shapekeys(mesh)
        for modifier in mesh.modifiers:
            if modifier.type == "ARMATURE":
                modifier.object = working_armature
                break
        else:
            modifier = mesh.modifiers.new(name="Armature", type="ARMATURE")
            modifier.object = working_armature
        bpy.ops.object.modifier_apply(modifier=modifier.name)
        modifier = mesh.modifiers.new(name="Armature", type="ARMATURE")
        modifier.object = reference_armature
        matrix_world = mesh.matrix_world.copy()
        mesh.parent = reference_armature
        mesh.matrix_parent_inverse = reference_armature.matrix_world.inverted()
        mesh.matrix_world = matrix_world

    for pbone in working_armature.pose.bones:
        for constraint in list(pbone.constraints):
            if constraint.name == "sbox_first_person_reference_rotation":
                pbone.constraints.remove(constraint)


def finalize_first_person_reference_armature(working_armature, reference_armature):
    bpy.data.objects.remove(working_armature, do_unlink=True)
    reference_armature.name = "First Person Arms Armature"
    reference_armature.data.name = "First Person Arms Skeleton"
    reference_armature.hide_set(False)
    reference_armature.hide_viewport = False
    reference_armature.hide_render = False
    return reference_armature


def duplicate_first_person_arm_meshes(
    context,
    source_armature,
    target_armature,
    template_profiles,
    threshold,
    match_template_thickness=True,
    template_thickness_scale=1.10,
    reweight_wrist_to_hand=True,
    wrist_reweight_radius=0.16,
):
    import bmesh
    source_meshes = model_mesh_objects(context.scene, source_armature)
    if not source_meshes:
        raise RuntimeError("No meshes are bound to the assigned source armature.")
    collection = ensure_scene_collection(context.scene, FIRST_PERSON_COLLECTION)
    target_bone_names = {bone.name for bone in target_armature.data.bones}
    created = []
    removed_vertices = 0
    scanned_vertices = 0
    kept_vertices = 0
    moved_meshes = 0
    removed_shapekeys = 0
    retargeted_vertices = 0
    reweighted_vertices = 0
    
    for mesh in source_meshes:
        index_to_name = {group.index: group.name for group in mesh.vertex_groups}
        delete_group = mesh.vertex_groups.get(FP_DELETE_GROUP)
        delete_group_index = delete_group.index if delete_group else None
        forced_group_indices = {
            "L": {
                group.index
                for group in (
                    mesh.vertex_groups.get(fp_attachment_group_name(FP_MARK_HAND, "L")),
                    mesh.vertex_groups.get(fp_attachment_group_name(FP_MARK_FOREARM, "L")),
                )
                if group
            },
            "R": {
                group.index
                for group in (
                    mesh.vertex_groups.get(fp_attachment_group_name(FP_MARK_HAND, "R")),
                    mesh.vertex_groups.get(fp_attachment_group_name(FP_MARK_FOREARM, "R")),
                )
                if group
            },
        }
        side_keep = {"L": [], "R": []}
        
        for vertex in mesh.data.vertices:
            scanned_vertices += 1
            delete_marked = vertex_has_group_weight(vertex, delete_group_index)
            forced_keep = {
                side: any(vertex_has_group_weight(vertex, group_index) for group_index in group_indices)
                for side, group_indices in forced_group_indices.items()
            }
            side = dominant_arm_side(vertex, index_to_name)
            keep = False
            if side and not delete_marked:
                max_weight = 0.0
                for assignment in vertex.groups:
                    group_name = index_to_name.get(assignment.group)
                    if group_name and first_person_arm_weight_bone(group_name):
                        max_weight = max(max_weight, assignment.weight)
                
                # 使用最大权重而不是单个权重
                if max_weight >= threshold:
                    keep = True
            
            keep_left = not delete_marked and (forced_keep["L"] or (keep and side == "L"))
            keep_right = not delete_marked and (forced_keep["R"] or (keep and side == "R"))
            if keep_left or keep_right:
                kept_vertices += 1
            side_keep["L"].append(keep_left)
            side_keep["R"].append(keep_right)
                
        for side, keep_vertices in side_keep.items():
            if not any(keep_vertices):
                continue
            copy_obj = mesh.copy()
            copy_obj.data = mesh.data.copy()
            copy_obj.animation_data_clear()
            copy_obj.name = f"{mesh.name}_first_person_arms_{side}"
            collection.objects.link(copy_obj)
            removed_shapekeys += remove_mesh_shapekeys(copy_obj)
            for old_collection in list(copy_obj.users_collection):
                if old_collection != collection:
                    old_collection.objects.unlink(copy_obj)
            bm = bmesh.new()
            bm.from_mesh(copy_obj.data)
            bm.verts.ensure_lookup_table()
            bm.verts.index_update()
            delete_verts = [vert for vert in bm.verts if vert.index >= len(keep_vertices) or not keep_vertices[vert.index]]
            removed_vertices += len(delete_verts)
            if delete_verts:
                bmesh.ops.delete(bm, geom=delete_verts, context="VERTS")
            remaining_vertices = len(bm.verts)
            bm.to_mesh(copy_obj.data)
            bm.free()
            copy_obj.data.update()
            if remaining_vertices == 0:
                bpy.data.objects.remove(copy_obj, do_unlink=True)
                continue
            moved_meshes += 1
            reweighted_vertices += apply_first_person_attachment_marks(copy_obj, side)
            collapse_first_person_unsupported_groups(copy_obj, source_armature, target_bone_names)
            repair_first_person_unweighted_vertices(copy_obj, source_armature, side)
            if reweight_wrist_to_hand:
                reweighted_vertices += reweight_wrist_vertices_to_hand(
                    copy_obj, source_armature, side, wrist_reweight_radius
                )
            retargeted_vertices += retarget_mesh_to_first_person_template(copy_obj, source_armature, target_armature, side)
            if match_template_thickness:
                inflate_mesh_to_template_profile(
                    copy_obj,
                    target_armature,
                    template_profiles,
                    side,
                    template_thickness_scale,
                )
            for modifier in list(copy_obj.modifiers):
                if modifier.type == "ARMATURE":
                    modifier.object = target_armature
            if not any(modifier.type == "ARMATURE" for modifier in copy_obj.modifiers):
                modifier = copy_obj.modifiers.new(name="Armature", type="ARMATURE")
                modifier.object = target_armature
            matrix_world = copy_obj.matrix_world.copy()
            copy_obj.parent = target_armature
            copy_obj.matrix_parent_inverse = target_armature.matrix_world.inverted()
            copy_obj.matrix_world = matrix_world
            copy_obj.hide_set(False)
            copy_obj.hide_viewport = False
            copy_obj.hide_render = False
            created.append(copy_obj)
            
    if not created:
        raise RuntimeError(
            "No arm mesh was created. "
            f"Scanned {scanned_vertices} vertices and found {kept_vertices} arm-weighted vertices. "
            "Try lowering the weight threshold or check the source vertex group names."
        )
    if bpy.context.object:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        target_armature.select_set(True)
        for obj in created:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = created[0]
    return (
        created,
        removed_vertices,
        kept_vertices,
        moved_meshes,
        removed_shapekeys,
        retargeted_vertices,
        reweighted_vertices,
    )


def export_first_person_arms_fbx(context, armature, meshes, filepath):
    filepath = bpy.path.abspath(filepath)
    if not filepath:
        raise RuntimeError("First person arms export path is empty.")

    output_dir = os.path.dirname(filepath)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    if bpy.context.object:
        bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    armature.select_set(True)
    for mesh in meshes:
        mesh.select_set(True)
    context.view_layer.objects.active = armature

    bpy.ops.export_scene.fbx(
        filepath=filepath,
        use_selection=True,
        object_types={"ARMATURE", "MESH"},
        add_leaf_bones=False,
        primary_bone_axis="Y",
        secondary_bone_axis="X",
        path_mode="COPY",
        bake_anim=False,
    )
    return filepath


def delete_source_full_body_model(scene, armature):
    meshes = model_mesh_objects(scene, armature)
    removed = len(meshes)
    for mesh in meshes:
        bpy.data.objects.remove(mesh, do_unlink=True)
    if armature and armature.name in bpy.data.objects:
        bpy.data.objects.remove(armature, do_unlink=True)
        removed += 1
    return removed
